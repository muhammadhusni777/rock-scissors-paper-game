materi materi zoom meeting 20 februari 2021 oleh muhammad husni

proteus yang digunakan adalah proteus 8.9

i hope you like this content :)